To run the TestFlamMap sample run the batch file:
Run2427464.bat

This batch file invokes TestFlamMap using 2427464Cmd.txt for command lines to TestFlamMap

